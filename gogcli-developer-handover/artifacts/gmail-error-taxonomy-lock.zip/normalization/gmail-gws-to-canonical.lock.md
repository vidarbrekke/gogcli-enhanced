# Gmail gws → gog canonical error normalization (LOCKED RULESET)

## Inputs (gws)
`gws` returns errors as JSON on **stdout**:
```json
{"error":{"code":401,"message":"...","reason":"authError"}}
```

## Output (canonical gog error payload)
Your control plane must normalize provider errors to:
```json
{
  "error": {
    "message": "...",
    "error_code": "unauthenticated|permission_denied|not_found|invalid_argument|resource_exhausted|unknown",
    "service": "gmail",
    "operation": "users.labels.list|users.labels.get",
    "resource_id": "<label-id-if-known>",
    "http_status": 401,
    "google_reason": "authError"
  }
}
```

## Outcome classification (provider-agnostic)
Treat as ERROR if:
- exit_code != 0, OR
- stdout JSON contains top-level `error`, OR
- stderr JSON contains top-level `error`

## Mapping table (authoritative)
- http_status = `error.code`
- google_reason = `error.reason`
- message = `error.message` (NON-CONTRACTUAL; compare as drift only)
- service/operation/resource_id = derived from invocation context (argv/params), NOT message text

## Canonical error_code mapping (authoritative)
- 401 → unauthenticated
- 403 → permission_denied
- 404 → not_found
- 400 → invalid_argument
- 429 → resource_exhausted
- else → unknown

## Contract stance (anti-churn)
- `error_code` + `http_status` are contract.
- `google_reason` is drift unless a consumer needs it; do not fail parity solely on google_reason changes.
