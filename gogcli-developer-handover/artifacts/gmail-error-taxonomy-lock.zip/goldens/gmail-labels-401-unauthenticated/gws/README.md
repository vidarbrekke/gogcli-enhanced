gws 401 unauthenticated capture (real).
