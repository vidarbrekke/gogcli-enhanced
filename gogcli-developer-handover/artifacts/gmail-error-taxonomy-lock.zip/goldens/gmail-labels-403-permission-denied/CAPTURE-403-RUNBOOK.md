# Capture gws 403 golden (maintainer only)

The developer does **not** have access to any app or environment. The **403 (permission denied)** golden must be captured by someone with gws + Google Cloud Console access (e.g. repo maintainer) and committed so the developer can freeze the Gmail error taxonomy.

**If you see “The OAuth client was deleted”:** You are using a client that was removed in Google Cloud Console. Restore your working gws client (e.g. `cp ~/.config/gws/client_secret-gcloud-agent-cli.json ~/.config/gws/client_secret.json` if you have that backup) and use a **new**, non-deleted OAuth client for the 403 capture below.

## One-time steps (on your Mac, where gws is already set up)

1. **Create a new OAuth client (do not reuse a deleted or unknown client)**
   - Open [Credentials](https://console.cloud.google.com/apis/credentials) and select a project (e.g. gcloud-agent-cli).
   - Create credentials → OAuth client ID → **Desktop app**.
   - Download the JSON and save as `~/.config/gws/client_secret-no-gmail.json`.
   - **Optional for “no Gmail”:** In the OAuth consent screen for that project, you can limit which scopes are available; or use the repo script `scripts/get-drive-only-credentials.py` (point it at this new client’s JSON) to run a Drive-only OAuth flow and write `credentials-no-gmail.json`. Otherwise, use the client for `gws auth login` and hope the consent screen only grants limited scope (gws normally requests Gmail too).

2. **Use that client for gws (without touching your main gws auth)**
   ```bash
   cp ~/.config/gws/client_secret.json ~/.config/gws/client_secret-backup.json
   cp ~/path/to/downloaded_client_secret_no_gmail.json ~/.config/gws/client_secret.json
   gws auth logout
   gws auth login
   ```
   Complete the browser flow (you’re now authorized with no Gmail scope).

3. **Export and capture 403**
   ```bash
   gws auth export --unmasked > ~/.config/gws/credentials-no-gmail.json
   cd /path/to/gogcli-enhanced
   GOOGLE_WORKSPACE_CLI_CREDENTIALS_FILE=~/.config/gws/credentials-no-gmail.json gws gmail users labels list --params '{"userId":"me"}' > docs/merge/goldens/gmail-labels-403-forbidden-gws.json
   ```

4. **Restore your main gws client**
   ```bash
   cp ~/.config/gws/client_secret-backup.json ~/.config/gws/client_secret.json
   gws auth login
   gws auth export --unmasked > ~/.config/gws/credentials.json
   export GOOGLE_WORKSPACE_CLI_CREDENTIALS_FILE=~/.config/gws/credentials.json
   ```

5. **Edit the golden**  
   Open `docs/merge/goldens/gmail-labels-403-forbidden-gws.json` and remove any `_replace_with_*` key so the file contains only the `error` object from gws stdout.

6. **Commit and push**
   ```bash
   git add docs/merge/goldens/gmail-labels-403-forbidden-gws.json docs/merge/CAPTURE-403-RUNBOOK.md
   git commit -m "docs(merge): add 403 golden and capture runbook for developer"
   git push
   ```

After this, the developer has a real 403 golden and can complete the Gmail error taxonomy mapping without needing any app or environment.
