# CI gating for Gmail error taxonomy lock

## Goal
Lock canonical mapping for Gmail errors using real provider goldens:
- 401 unauthenticated (required)
- 404 not_found (required)
- 403 permission_denied (required for promotion only; may be placeholder until captured)

## Recommended gates
1) Always run parity normalization + schema validation for:
   - gmail-labels-401-unauthenticated
   - gmail-labels-get-404-not-found
2) If 403 golden is placeholder, do NOT fail main CI.
   - Mark as REQUIRED for any PR that:
     - changes provider routing defaults for Gmail, OR
     - bumps gws version, OR
     - changes Gmail normalization mapping table.
