# Parity runner diff rules (v2): native gog vs gws (and other providers)

## 0) Parse rules
Capture:
- `stdout` (string), `stderr` (string), `exit_code` (int)

Parse JSON if possible:
- `stdout_json` if stdout is valid JSON
- `stderr_json` if stderr is valid JSON

## 1) Outcome classification (provider-agnostic)

**Error outcome** if ANY is true:
- `exit_code != 0`
- `stderr_json` is an object with top-level `error`
- `stdout_json` is an object with top-level `error`  ← (needed for gws)

Else **success outcome**.

## 2) Canonicalize error (before comparison)

### 2.1 Choose source
- If both stdout and stderr contain JSON error objects, prefer **stderr** (native convention).
- Else use whichever stream contains the JSON error object.

### 2.2 Normalize provider error to canonical fields
- Native gog: already canonical (may include `error_code`, `service`, `operation`, etc.)
- gws: apply `gws-normalization.md` (map `code`/`reason`, inject context)

## 3) Error comparison

**Breaking diffs**
- canonical `error.error_code` differs (when present in both)
- `error.http_status` differs (when present in both)
- `error.service` differs (when present in both)
- `error.operation` differs (when present in both)
- `error.resource_id` differs (when present in both)

**Non-breaking drift**
- `error.message` differs
- `error.google_reason` differs (unless you lock it as contract for a command)

## 4) Success comparison
- Validate success JSON against command result schema (strict payload fields).
- Apply command-specific normalization:
  - lists compare as sets keyed by id unless order is a contract promise.

## 5) Reporting
Emit:
- `breaking`: list of json-pointer diffs
- `drift`: list of json-pointer diffs
- `provider`: name + version
- `normalization_applied`: list
