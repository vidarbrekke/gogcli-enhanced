# Command-specific parity: Gmail labels (Tier A)

Applies to:
- `gmail labels list`
- `gmail labels get`

## Validated from gws samples
- gws emits error JSON on stdout with shape: `error.code` (int), `error.message` (string), `error.reason` (string).

## Normalization rules

### labels.list success
- Compare `labels` as a **set keyed by `id`**.
- For each label:
  - Require type stability for: `id` (string), `name` (string), `type` (string when present)
  - Treat numeric counters (`messagesTotal`, etc.) as **optional** unless your native contract guarantees them.
- Allowed drift:
  - ordering of `labels`
  - presence/absence of optional visibility/count fields

### labels.get not_found error
- Require canonical `error_code == not_found` (after mapping)
- Require `http_status == 404` when present
- Allowed drift: message text, google_reason string

### auth error (unauthenticated)
- Require canonical `error_code == unauthenticated` (after mapping)
- Require `http_status == 401` when present

## Notes (keep-up risk)
Do NOT chase new fields returned by Gmail unless a consumer needs them.
Prefer strict schemas that only promise the minimal fields your scripts rely on.
