# Provider normalization: gws → canonical gog envelope

This document is derived from `GWS-SAMPLES.md` and native envelope samples.

## Validated observations (from samples)
- `gws` emits JSON for **both success and error on stdout** (stderr may be empty or may contain non-JSON hints).
- Error JSON shape: `{"error": {"code": <int>, "message": <string>, "reason": <string>}}`

## Required normalization (parity runner)

### 1) Stream handling
- If stdout parses as JSON and contains top-level `error`, treat as **error outcome** even if stderr is empty.
- Prefer stderr JSON error if both streams contain valid JSON errors (native case).

### 2) Map gws fields → canonical error fields

| Canonical | gws sample field | Rule |
|---|---|---|
| `error.message` | `error.message` | copy |
| `error.http_status` | `error.code` | copy |
| `error.google_reason` | `error.reason` | copy |
| `error.error_code` | derived | map via table below |
| `error.service` | derived | inject from invocation context (e.g., `gmail`) |
| `error.operation` | derived | inject from invocation context (e.g., `labels.list`) |
| `error.resource_id` | derived | inject if an ID is present in params (e.g., label id) |

### 3) Error code mapping table (initial)

> **Assumption:** gog uses a stable taxonomy similar to: `unauthenticated`, `permission_denied`, `not_found`, `invalid_argument`, `resource_exhausted`, `unknown`.
> Update to match your actual gog taxonomy if different.

| gws `error.code` | gws `error.reason` | canonical `error_code` |
|---:|---|---|
| 401 | `authError` | `unauthenticated` |
| 403 | `forbidden` / `insufficientPermissions` | `permission_denied` |
| 404 | `notFound` | `not_found` |
| 400 | `invalidArgument` | `invalid_argument` |
| 429 | `rateLimitExceeded` / `userRateLimitExceeded` | `resource_exhausted` |
| * | * | `unknown` |

### 4) Gmail-specific injection (examples)
- `gws gmail users labels list` → service=`gmail`, operation=`users.labels.list`
- `gws gmail users labels get` → service=`gmail`, operation=`users.labels.get`, resource_id=`<id>`

Injection should be deterministic and derived from argv/params, not from error message strings.

## Contract stance (anti-churn)
- Treat `error.message` as non-contractual (allowed to differ).
- Treat `http_status` + mapped `error_code` as contractual once you have goldens for those cases.
